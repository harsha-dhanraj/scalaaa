object helloWorld{
def main(args : Array[String]){
println("This is scala script.Happy scala programming")
}
}
