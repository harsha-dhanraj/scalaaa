val kg=72.57//160lbs

val ht = 1.727//68 inches

val bmi = kg/(ht*ht)

if(bmi<18.5) println("underweight")
else if(bmi<25) println("normal weight")
else println("overweight")


