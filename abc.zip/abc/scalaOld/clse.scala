val hour=6

 val isopen = {
 val opens=9
 val closes = 20
println("operating hours : "+
opens + "-" + closes)

if(hour >= opens && hour <= closes ){
true
}
else{
false }
}

println(isopen)
      

