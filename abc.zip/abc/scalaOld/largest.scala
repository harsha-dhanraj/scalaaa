object largest {
	def main(args : Array[String]){
	var num1 = 20;
	var num2 = 30;
	if(num1 > num2){
	println("largest no is: " + num1);
					}

	else {
		println("largest no is: "+ num2);
		}
}
}
