object demo{
	def main(args:Array[String]){
		var mvar : Int =10;
		val mval : String = "Hello scala with datatype declaration";
		var mvar1 = 20;
		val mval1 = "without datatype declaration";

	println(mvar); println(mval); println(mvar1); println(mval1s);
}
}
