
import Array._

object assinment1 {
  def main(args:Array[String]){
  val List = Array(1,9,-1,2,3,4,5,-4)
  
  val res = for (i <- 0 until List.length if List(i) < 0)yield i
  for (ele <- res)
    println(" " + ele +" ")
    println("length is "+ res.length)
  
  
  }
}