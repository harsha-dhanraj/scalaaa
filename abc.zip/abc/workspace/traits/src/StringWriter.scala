
abstract class Writer(){
  def write(msg:String)
}

trait Profanityfilter extends Writer{
  abstract override def write(msg:String){
    super.write(msg.replace("stupid", "S*****"))
  }
  }


trait UpperCaseFilter extends Writer{
  abstract override def write(msg:String)=super.write(msg.toUpperCase())
}

class StringWriter extends Writer{
  
  val target=new StringBuilder()
  def write(msg:String)=target.append(msg)
  override def toString()=target.toString()
  
//  trait UpperCaseFilter extends Writer{
//    def write(msg:String)={
//      msg.toUpperCase()
//    }
//  }
  
}
  
  object TraitChains{
    
    def writeStuff(writer:Writer)={
      writer.write("This is stupid")
      println(writer)
    }
    
     def main(args:Array[String]){
       writeStuff(new StringWriter)
       writeStuff(new StringWriter with UpperCaseFilter)
       writeStuff(new StringWriter with Profanityfilter)
     }
  }
   