//
//trait Friend {
//  val name:String
//  
//  def listen()=println("I am " + name   + " listening")
//  
//}
//
//class Human(val name:String)extends Friend
//
//class Animal(val name:String)
//
//class Dog(overrides val name:String) extends Animal(name) with Friend
//
//  object TraitExample{
//  
//    def main(args:Array[String]){
//      
//     val sameer=new Human("sameer")
//     sameer.listen()
//     
//     val buddy=new Dog("Buddy")
//     buddy.listen()
//  }
//}
