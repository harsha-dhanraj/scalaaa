//
//trait Friend {
//  val name:String
// 
//  def listen()=println("I am " + name   + " listening") 
//    
//}
//
//class Human(val name:String) extends Friend
//
//class Animal(val name:String)
//
//class Dog(override val name:String) extends Animal(name) with Friend
//
//class Cat(override val name:String) extends Animal(name) 
//
//
//object traitExample2 {
//  
//  def seekHelp(friend:Friend)={
//    friend.listen()
//  }
//  
//  def main(args:Array[String]){
//    
//  
//  val sameer=new Human("sameer")
//   
//   val buddy=new Dog("Buddy")
//    
//   val tom=new Cat("Tom") with Friend
//   
//   seekHelp(sameer)
//   seekHelp(buddy)
//    seekHelp(tom)
//      
//}
//}