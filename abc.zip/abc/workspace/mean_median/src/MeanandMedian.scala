
import scala.math._

object MeanandMedian {
   def main(args:Array[String]){
     
     val arr=Array(14,20,45,29,40,55,33,33)
     
     val totalelements=arr.length
     println(totalelements)
     
     if(totalelements % 2 == 0)
       println((arr((totalelements/2)-1)+arr(totalelements/2))/2)
       
     else
       println("Median is:" + arr(totalelements/2))
       
       println("mean is: " + (arr.sum.toDouble/arr.length.toDouble))
   }
   
}