package first_project

object tabulate {
  def main (args:Array[String]){
    val square =List.tabulate(6)(n=> n*n)
    println("square"+square)
    val mul =List.tabulate(4,5)(_*_)
    println("mul:"+mul)
  }
}