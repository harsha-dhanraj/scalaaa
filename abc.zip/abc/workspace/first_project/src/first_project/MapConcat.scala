package first_project

object MapConcat {
  
   def main(args:Array[String]){
    
    val colours1=Map("red"->"#FF","azure"->"#FF","Peru"->"#TT")
    val colours2=Map("blue"->"#OF","Yellow"->"#FP","red"->"#TP")
    
    
    var colours=colours1++colours2
    println("colour1++colour2:"  + colours)
    
    colours=colours1.++(colours2)
     println("colour1.++(colour2):" + colours)
  }
  
}


