package first_project

object concatenation {
  def main(args:Array[String]){
    val fruit1 =Set("apples","oranges","pears")
    val fruit2=Set("mangoes","bananas")
    
    //u
    var fruit=fruit1 ++ fruit2
    println("fruit1 ++ fruit2:"+fruit)
    
    
   var fruit7 =fruit1.++(fruit2)
    println("fruit1.++(fruit2):"+fruit7)
}
}