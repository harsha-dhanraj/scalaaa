package first_project

object keyMap {
  
   def main(args:Array[String]){
    
    val colours=Map("red"->"#FF","azure"->"#FF","Peru"->"#TT")
    
    if(colours.contains("red")){
      println("red key exist value:"+colours("red"))
    }else{
      println("red key does not exist")
      
    }
    if(colours.contains("maroon")){
      println("maroon key exist:"+colours("maroon"))
    }else{
      println("maroon key does not exist")
    }
    
    }
}