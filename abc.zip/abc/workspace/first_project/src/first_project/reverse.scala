package first_project

object reverse {
  def main(args:Array[String]){
    val fruit ="apples"::("oranges"::("pears"::Nil))
    println("before reverse fruit:"+fruit)
    println("After reverse fruit:"+fruit.reverse)
  }
}