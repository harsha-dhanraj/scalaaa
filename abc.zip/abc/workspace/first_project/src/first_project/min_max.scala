package first_project

object min_max {
  def main(args:Array[String]){
    val num =Set(1,2,3,4,5,6)
    
    println("Min elem is Set (1,2,3,4,5,6):"+num.min)
    println("Max elem is Set (1,2,3,4,5,6):"+num.max)
}
}