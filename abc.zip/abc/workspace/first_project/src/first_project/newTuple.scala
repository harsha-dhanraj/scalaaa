package first_project

object newTuple {
  def main(args:Array[String]){
    val t=new Tuple2("Scala","hello")
    println("swapped Tuple:"+t.swap)
    
    //----------------------------------------------------------------
    
    val capitals=Map("france"->"paris","japan"->"TOKYO")
    
    println("caitals.get(\"france\"):"+capitals.get("france"))
    println("caitals.get(\" India\"):"+capitals.get("india"))
    
    
    //---------------------------------------------------------------------------
    
      val capitals1=Map("france"->"paris","japan"->"TOKYO")
    
    println("caitals1.get(\"france\"):"+capitals1.get("france"))
    println("caitals1.get(\" India\"):"+capitals1.get("india"))
  }
    
    def show(x:Option[String])=x match{
      case Some(s)=>s
      case None=>"?"
        
  
        
    
    
    
  }
}