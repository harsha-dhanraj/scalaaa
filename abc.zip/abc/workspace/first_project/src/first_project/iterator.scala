package first_project

object iterator {
   def main(args:Array[String]){
     val ita=Iterator(20,40,50,60)
     val itb=Iterator(20,40,50,60)
     
     println("max"+ita.max)
     println("min"+itb.min)
     
     
   }
}