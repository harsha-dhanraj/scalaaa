package first_project

object colours {
   def main(args:Array[String]){
     val colours=Map("red"->"#FF0000","azure"->"#F0FFFF","peru"->"#CD853F")
     
     val nums:Map[Int,Int]=Map()
     println("Keys in colour:"+colours.keys)
     println("value in colour:"+colours.values)
     println("check if colour is emp:"+colours.isEmpty)
     println("nums is Empt:"+nums.isEmpty)
   
   }
}