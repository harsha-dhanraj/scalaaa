package first_project

object sets {
  def main(args:Array[String]){
    val fruit =Set("apples","oranges","pears")
    val nums:Set[Int]=Set()
    
    println("Head of fruit:"+fruit.head)
    println("tail of fruit:"+fruit.tail)
    println("check is fruit is emplty:"+fruit.isEmpty)
    println("Head od nums is Empty:"+nums.isEmpty)
}
}