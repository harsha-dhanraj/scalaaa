package first_project

object intersect {
   def main(args:Array[String]){
     val num1=Set(1,2,3,4,5,6)
     val num2=Set(1,2,37,47,758,9)
     
     println("num1.&(num2):"+num1.&(num2))
      println("num1.intersect(num2):"+num1.intersect(num2))
     
     }
}