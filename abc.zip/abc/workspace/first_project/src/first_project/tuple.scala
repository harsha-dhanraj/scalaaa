package first_project

object tuple {
  def main(args:Array[String]){
    val t=(4,5,6,7)
    val sum=t._1+t._2+t._3+t._4
    println("sum"+sum)
  //--------------------------------------------------------------
    
    
    val t1=(4,5,6,7)
    t1.productIterator.foreach{i=>println("value="+i)}
  
  }
}


