package first_project

object convertToString {
   def main(args:Array[String]){
     val t=new Tuple3(1,"hello",Console)
     
     println("conc string:"+t.toString)
     
     
     
   }
}