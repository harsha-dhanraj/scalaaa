import scala.collection.mutable.ArrayBuffer

object rmv_duplicates {
   def main(args:Array[String]){
   
     val arr = Array[Int](1,-8,2,90,5,-4,7,2,6,7,8)
     val b = arr.distinct
     for(i<-0 until b.length)
       print(" " +b(i)+" ")
   }
}