
  object swap {
    
      
  def main(args:Array[String]){
    
  val a = Array[Int](1,2,3,4,5,6)
  
 for (i <- 0 until a.length ){
   if(a.length % 2 == 0){
     if (i%2 ==1){
   
   
      val temp = a(i)
     a(i) = a(i-1)
     a(i-1)= temp
   }
   }
 }
  for(i <- 0 until a.length)
    print(" " + a(i)+ " ")
  
  }
}
  
