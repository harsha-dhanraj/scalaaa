//positive and negative number should separate

import scala.collection.mutable.ArrayBuffer
object arrayexercise {
  
   def main(args:Array[String]){
    
    val a= Array[Int](2,6,-1,9,0,-4,-6)
    val pos,oth = new ArrayBuffer[Int]
    
    for(i<-0 until a.length)
    {
      if(a(i) > 0) pos += i
      else oth += i
    }
    
    
    val ab = new ArrayBuffer[Int]
    ab ++=(for(i <- pos) yield a(i))
    ab --=(for(i <- oth) yield a(i))
    ab.toArray
    for(i<-0 until ab.length)
      print(ab(i)+", ")
    
  }
}
   
  