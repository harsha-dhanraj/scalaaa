object ASCII {
     def main(args:Array[String]){
     
     
     val res= for(i<- 65 until 128) yield i
     
     for(t<-res)
      print(" "+ t.toChar + " ")
     
     }
}