

object marks_3_exam {
  def main(args:Array[String]){
    
    println("Enter marks of 3 subjects=  ")
    val marks1 = scala.io.StdIn.readInt()
    println("Marks of 1 subject : " + marks1)
     val marks2 = scala.io.StdIn.readInt()
    println("Marks of 2 subject : " + marks2)
    val marks3 = scala.io.StdIn.readInt()
    println("Marks of 3 subject : " + marks3)
    val total=300;
    
    
    val sum= (marks1+marks2+marks3);
    
    val per= (sum * 100) / total;
    
    println("percentage of 3 subject : " + per)
    
    
    if(per>90)
      {
        println("Grade is A")
      }
    else if(per>70 && per<90) 
      {
          println("Grade is B")
          
      }
    else if (per<70) 
      {
          println("Grade is C")
      }
    
  }
  
}