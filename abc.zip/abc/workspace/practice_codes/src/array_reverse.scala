
import Array._

object array_reverse {
   def main(args:Array[String]){
    
    val arr = Array("AAa","bBB","cCC","dDD")
    
   var str=arr.reverse
   
   for(res<-str)
     println(res)
     
     println("------------------------")
     
     for(i<- 0 to arr.length-1)
       println(arr(i).reverse)
     
   }  
}