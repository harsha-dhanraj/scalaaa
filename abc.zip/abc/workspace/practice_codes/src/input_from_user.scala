

object input_from_user {  
  def main(args:Array[String]){    
    println("Input some string ")
    val input = scala.io.StdIn.readLine()
    println("String u typed is : " + input)
  }
}
