  
import scala.math._
import Array._

object sum_even_odd {


  
  def main(args:Array[String]){
    
    val arr=Array(14,20,45,29,40,55,33,39)
    
    var a = for(i <- 0 until arr.length if (arr(i) % 2 == 0)) yield arr(i)
    print("even=" + a.sum + " ")
   
    println("")
    
    var b = for(i <- 0 until arr.length if (arr(i) % 2 != 0)) yield arr(i)
      print("odd=" +b.sum + " ")
  }

}