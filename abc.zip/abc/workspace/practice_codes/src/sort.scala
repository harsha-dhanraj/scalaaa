
import scala.math._
import Array._

object sort {
  

    def main(args:Array[String]){
      
      val arr=Array[Int](1,-8,2,90,5,-4,6,7,8)
      val sorted = arr.sorted         //for ascending order
      val ar = arr.sortWith(_ < _)   //for ascending order
      val ar1 = arr.sortWith(_ > _)   //for descending order
      
      
      for(i<- 0 until arr.length)
        print(" " +ar(i)+" ")
        println()
         for(i<- 0 until sorted.length)
        print(" " +sorted(i)+" ")   
         println()
        for(i<- 0 until ar1.length)
        print(" " +ar1(i)+" ")
    }
}
