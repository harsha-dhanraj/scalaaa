

object mode_program {
  

  def main(args:Array[String]){
    
    val arr=Array(2,4,5,8,1,3)
    
  }
}