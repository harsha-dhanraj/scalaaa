import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.log4j._

object calculate_no_of_E {
 
  def main(args: Array[String]) {
   
    // Set the log level to only print errors
    Logger.getLogger("org").setLevel(Level.ERROR)
    
     // Create a SparkContext using every core of the local machine
    val sc = new SparkContext("local[*]", "wordsuppercase")   
    
    // Read each line of my book into an RDD
   val input = sc.textFile("/home/iot/ankita_anagha/data_management_analysis/Spark-codebase/book.txt")
    
   val rdd =input.flatMap(_.toList);
   

    // Filter out all but TMIN entries
    val rdd1 = rdd.filter(x => x == "E" || x=='e')
    
    println(rdd1.count())
    
    //println(input.flatMap(_.toList).count);
 
} 

}