
import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.log4j._

object read_print_uppercase {
  
     /** Our main function where the action happens */
  def main(args: Array[String]) {
   
    // Set the log level to only print errors
    Logger.getLogger("org").setLevel(Level.ERROR)
    
     // Create a SparkContext using every core of the local machine
    val sc = new SparkContext("local[*]", "wordsuppercase")   
    
    // Read each line of my book into an RDD
    val input = sc.textFile("/home/iot/ankita_anagha/data_management_analysis/Spark-codebase/sample.txt")
    
   val words=input.flatMap(x=>x.split("\\W+"));
    
     // Normalize everything to uppercase
    val uppercaseWords = words.map(x => x.toUpperCase())
     uppercaseWords.foreach(println)
}
  
}