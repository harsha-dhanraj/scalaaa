import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.log4j._

/** Count up how many of each word occurs in a book, using regular expressions. */

object customer_orders_assignment {
  
  def parseLine(line: String) = {
      
      // Split by commas
      
      val fields = line.split(",")
      
      val custID = fields(1).toInt
      
      val amountSpent = fields(2).toFloat
      
     (custID,amountSpent)
     
    }
  
  def main(args: Array[String]) {
   
      // Set the log level to only print errors
    
    Logger.getLogger("org").setLevel(Level.ERROR)
        
    // Create a SparkContext using every core of the local machine
    
    val sc = new SparkContext("local[*]", "CustomerAssignment")
  
    val customertOrders= sc.textFile("/home/iot/ankita_anagha/data_management_analysis/Spark-codebase/customer-orders.csv")
    
    val rdd = customertOrders.map(parseLine)
     
    val totalsByCustomer = rdd.reduceByKey((x,y) => (x+y)).sortByKey()
      
    val customerListSorted = totalsByCustomer.map(x=>(x._2,x._1)).sortByKey()
      
     val resultList=customerListSorted.collect()
      
      resultList.foreach (println)
      
      for(result<-resultList){
        
        val amount=result._1
        val custID=result._2
      
        println(s"$custID: $amount")
        
        println("Lowest 5: ")
        resultList.take(5).foreach(println)
        println("top 5: ")
        resultList.take(5).reverse.foreach(println)
       
  }
     
    }
    }