

object create_uniform_list_fill_func {
  
   def main(args:Array[String]){
     
     val fruit=List.fill(3)("apples")
     println("fruit: "+fruit)
     
     val num=List.fill(10)(2)
     println("num: "+num)
   }
}