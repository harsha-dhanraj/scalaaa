

object scala_lists {
  
    def main(args:Array[String]){
  
  val fruit:List[String]=List("apples","oranges","pears")
  println(fruit)
  
   val fruit1="apples"::("oranges"::("pears"::Nil))
   println(fruit1)
  
  val nums:List[Int]=List(1,2,3,4)
  println(nums)
  
   val num1= 1::(2::(3::(4::Nil)))
   println(num1)
  
  val empty:List[Nothing]=List()
  println(empty)
  
  val empty1=Nil
  println(empty1)
  
  val dim:List[List[Int]]=
    List(
        List(1,0,0),
        List(0,1,0),
        List(0,0,1)
        )
   println(dim)
   
    val dim1=(1::(0::(0::Nil)))::
       (0::(1::(0::Nil)))::
       (0::(0::(1::Nil)))::Nil
   println(dim1)
 
}
}