

object concatenate_list {
  
    def main(args:Array[String]){
     
      val fruit1="mango"::("oranges"::("pears"::Nil))
      val fruit2="apple"::("banana"::Nil)
     
      var fruit=fruit1:::fruit2 //concat using Set.:::() method
      println("fruit1:::fruit2: " +fruit)
      
      var fruit3=fruit1.:::(fruit2)
      println("fruit1.:::(fruit2): " +fruit3)
      
       var fruit4=List.concat(fruit1,fruit2)
      println("List.concat(fruit1,fruit2): " +fruit4)
      
     
     
   
   }
}