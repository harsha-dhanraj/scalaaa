

object extensibility_with_higher_order {
   def main(args:Array[String]){
     
     println(totalResultOverRange(11,i=>if(i%2==0)i else 0))
     
   }
   
   def totalResultOverRange(number:Int,codeBlock:Int=>Int)={
     var result=0
     for(i<-1 to number){
       result+=codeBlock(i)
     }
     result
   }
}