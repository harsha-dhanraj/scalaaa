

object immutable {
  
  def pow(x:Double,y:Double):Double=
    math.pow(x,y)
    
    def main(args:Array[String]){
    println(pow(2,5))
  }
}