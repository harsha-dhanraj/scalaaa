

object typeParameter {
   def main(args:Array[String]){
  def identity[A](a:A):A=a
   
  val s : String = identity[String]("hello")
  println(s) 
}
}