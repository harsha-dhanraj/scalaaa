

object NestedFun {
  def main(args:Array[String]){
    println(fact(0))
     println(fact(1))
      println(fact(2))
       println(fact(3))
  }
  
  def fact(i:Int):Int={
    
    def fact1(i:Int,accumulator: Int):Int ={
      if(i<=1)
        accumulator
      else
        fact1(i-1,i*accumulator)
    }
    fact1(i,1)
  }
}