

object funWithNamedArgument {
  def main(args:Array[String]){
    printInt(b=5,a=7)
  }
  
  def printInt(a:Int,b:Int)={
    println("value a: " + a)
    println("value b: " + b)
  }
}