

object func_with_multiple_parameters {
  
    def main(args:Array[String]){
    
    printValue(()=>42)
    
  }
    
  def printValue(generator:()=>Int)={
    println(s"Generated value is ${generator()}")
  }
}