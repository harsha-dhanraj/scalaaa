

object funArrayOfStrings {
      def main(args:Array[String]){
        printStr("hello","scala","python","nodeJs")
    }
    
    def printStr( args : String*)={
      var i : Int =0
      
      for (arg <- args){
        println("Arg value[" + i + "]="+ arg );
        i =i+1;
      }
    }
      
      
}