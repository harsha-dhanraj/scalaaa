

object nested_fun {
  def main(args:Array[String]){
    delay(time());
  }


def time()={
    println("getting time in nano seconds")
    System.nanoTime()
}

def delay(t: => Long)={
  println("in delayed method")
  println("param:" + t )
}
}