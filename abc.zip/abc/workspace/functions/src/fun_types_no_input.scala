

object fun_types_no_input {
  
    def logstart()= "="  * 5 + "\n Starting now \n" + " = " * 5   
   val start:()=> String=logstart
  
    
  def main(args:Array[String]){
    println(start())
   
   
  }
}