

object higher_order_function {
  
  def sum(a:Int,b:Int):Int={a+b}
  def sub(a:Int,b:Int):Int={a-b}
  def mul(a:Int,b:Int):Int={a*b}
  def div(a:Int,b:Int):Int={a/b}
  
  def calculator(f:(Int,Int)=>Int,arg1:Int,arg2:Int):Int={
    if(arg1>0 && arg2>0)
      f(arg1,arg2)
     else
       0
  }
  
  def main(args:Array[String]){
    println("Sum is:"+calculator(sum,20,10))
    println("Subtraction is:"+calculator(sub,20,10))
    println("Multiplication is:"+calculator(mul,20,10))
    println("Division is:"+calculator(div,20,10))
  }
  
}