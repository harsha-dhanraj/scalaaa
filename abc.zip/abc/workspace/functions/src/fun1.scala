import java.util.Date

object fun1 {
 
  def main(args:Array[String]){
    val date = new Date
    val logWithDateBound =log(date,_:String)
   
    logWithDateBound("msg1")
    Thread.sleep(60000)
    
    logWithDateBound("msg2")
    Thread.sleep(2000)
    
    logWithDateBound("msg3")
  }
  
  def log(date:Date,message:String)={
    println(date+"--"+message)
  }
  
}
