

object funNamedParameter {
   def main(args:Array[String]){
     def greet(prefix:String,name:String)= s"$prefix$name"
     val greeting1 = greet("MS.","Brown")
     val greeting2 = greet(name="Brown",prefix="Mr.")
     
     println(greeting1)
     println(greeting2)
   }
}