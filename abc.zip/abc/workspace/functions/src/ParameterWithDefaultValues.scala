

object ParameterWithDefaultValues {
    def main(args:Array[String]){
      
     def greet(prefix:String="",name:String)= s"$prefix$name"
     val greeting1 = greet(name="Brown")
    
     println(greeting1)
    // println(greeting2)
   }
}