
import Math._
object func_more_than_one_argument {
  
  def main(args:Array[String]){
    
    val arr=Array(1,2,3,4,5,6)
    
    val sumfold=arr.foldLeft(0){(sum,elem)=>sum+elem}
     println(s"sum of elements in array using fold $sumfold")
     
     //alternative to writing keyword fold
     val sumfold1=(0/:arr){(sum,elem)=>sum+elem}
     println(s"sum of elements in array using /: operator $sumfold1")
     
     val maxfold=arr.foldLeft(Integer.MIN_VALUE){(large,elem)=>Math.max(large,elem)}
     println(s"max of elements in array is using fold $maxfold")
     
      val maxfold1=(Integer.MIN_VALUE/:arr){(large,elem)=>Math.max(large,elem)}
     println(s"max of elements in array is using /: $maxfold1")
     
    val sum=inject(arr,0,(carry,elem)=>carry+elem)
    println(s"sum of elements in array is $sum")
    
    val max=inject(arr,Integer.MIN_VALUE,(carry,elem)=>Math.max(carry,elem))
     println(s"max of elements in array is $max")
    
  }
  
  def inject(arr:Array[Int],initial:Int,operation:(Int,Int)=>Int)={
  
    var carryOver=initial
    arr.foreach(element=>carryOver=operation(carryOver,element))
    carryOver
  }
}