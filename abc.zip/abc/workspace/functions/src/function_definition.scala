

object function_definition { 
  
  def main(args:Array[String]){
    
    println("multiplication is: "+multi(6,7))
    greeting();
    greeting;
    formatEuro(3.4645)
    formatEuro{val rate=1.32;0.235+0.7123+rate*5.32}
    
    
  }
  
   def multi(x:Int,y:Int):Int={x*y}

   def greeting()={println("greeting to all")}
   
  def formatEuro(amt:Double)=println(f"$amt%.2f")
   
 
   
   
 
}