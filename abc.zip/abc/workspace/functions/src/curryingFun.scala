

object curryingFun {
   def main(args:Array[String]){
    val str1 : String ="hello"
    val str2 : String ="scala"
    
    println("str1 + str2= "+ strcatlp(str1)(str2))
   }
   def strcatlp(s1:String)(s2:String)={
     s1+s2
   }
}