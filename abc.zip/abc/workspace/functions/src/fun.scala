
import java.util.Date
object fun {
  def main(args:Array[String]){
    val date = new Date
    log(date,"msg1")
    
    Thread.sleep(5000)
    log(date,"msg2")
    
    
    Thread.sleep(2000)
    log(date,"msg3")
  }
  def log(date:Date,message:String)={
    println(date+"--"+message)
  }
  
}