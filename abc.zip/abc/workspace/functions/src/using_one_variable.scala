

object using_one_variable {
  
  def pow(x:Double,y:Int):Double={
    
    var p=1.0; for(i<- 1 to y)p *=x; p
    
  }
    
  def main(args:Array[String]){
    println(pow(2,5))
  }
}