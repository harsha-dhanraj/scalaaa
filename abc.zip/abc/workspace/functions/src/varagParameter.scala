

object varagParameter {
  def main(args:Array[String]){
 
   // sum:(item:Int)Int
    
     println(sum(10,20,30))
 
  }
   def sum(item:Int*): Int={
     var total = 0 
     for (i<-item)total +=i
     total
     
     
  }
  
}