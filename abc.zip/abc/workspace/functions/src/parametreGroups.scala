

object parametreGroups {
   def main(args:Array[String]){
  val larger = max(20)(39)
  print(larger)
   }
   def max(x:Int)(y:Int)=if(x>y)x else y
}