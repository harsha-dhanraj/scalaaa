

object pluralize {
  
  def main(args:Array[String]){
   
    printplural("Cat",(v:String)=>println(v+"s"))
    printplural("Scala",(v:String)=>println(v.toLowerCase()))
    printplural("scala",(v:String)=>println(v.toUpperCase()))
    printplural("Hello There",(v:String)=>println(v.reverse))
    
  }
  
  def printplural(v:String,codeBlock:String=>Unit){
    
    codeBlock(v)
 }
  
}
  
