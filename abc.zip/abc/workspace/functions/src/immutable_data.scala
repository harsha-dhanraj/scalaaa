

object immutable_data {
  
  def pow(x:Double,y:Int,accum:Double=1):Double={
    
   if(y<1) accum
   
   else pow(x,y-1,accum*x)
    
  }
    
  def main(args:Array[String]){
    println(pow(2,5))
  }
}