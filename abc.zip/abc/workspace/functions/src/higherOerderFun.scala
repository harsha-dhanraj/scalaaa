

object higherOerderFun {
  def main(args:Array[String]){
     println(apply(layout,10))
  }
  def apply(f:Int => String, v:Int)=f(v)  //here apply is a higher order fun
  

  def layout[A](x:A)= "[ " + x.toString() + " ]"  //A is datatype of scala

}