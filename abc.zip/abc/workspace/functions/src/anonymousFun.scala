

object anonymousFun {
  def main(args:Array[String]){
  var mul = (x:Int,y:Int)=>x*y
  println(mul(3,4))
  
  var usrDir=() => {
    System.getProperty("user.dir")
  }
  println(usrDir())
  
  }
  
}