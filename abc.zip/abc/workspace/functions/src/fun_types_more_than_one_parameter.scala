

object fun_types_more_than_one_parameter {
  
   def max(a:Int,b:Int)=if(a>b)a else b
   
   val maximize:(Int,Int)=>Int=max
  
    
  def main(args:Array[String]){
    println(maximize(56,78))
   
   
  }
}