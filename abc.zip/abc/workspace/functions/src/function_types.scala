

object function_types {
  
   def double(x:Int):Int=x*2
   
   val mydouble:(Int)=>Int=double
   
   
   val mydoublecopy=mydouble
    
  def main(args:Array[String]){
    println(double(5))
    println(mydouble(5))  
    println(mydoublecopy(5))
   
  }
}