

object getMe_func {
  
   def getMe(x:String)={
    
    
    
  }
    
  def main(args:Array[String]){
    
  }
}