

object defaultParameter {
  def main(args:Array[String]){
    println("returned value: " + add())
  }
  
  def add(a: Int=5 , b:Int=7):Int = {
    var sum : Int =0
    sum = a+b
    return sum
  }
}