import Array._


object arrayTraversing {
  def main(args:Array[String]){
  val List = Array(1,9, 2, 3,4, 5)
    val a = Array(1,9, 2, 3,4, 5)

    """
  for (elem <- List)
    println(elem) """
    
  """  val result =   for (elem1 <- List) yield 2 * elem1
    for (elem1 <- result)
    print(" " + elem1 +" ")
    //println(result)  """
    
    val result1 = for (elem2 <- a if( (elem2 % 2) == 0))yield 2 * elem2
    for (elem2 <- result1)
    print(" " + elem2 +" ")
    
}
}