
import Array._
object concatArray {
  def main(args:Array[String]){
    var l1=Array(1.9,2.9,3.9,4.9)
    var l2=Array(3.9,8.9,0.9,6.9)
    
    var l3 = concat(l1,l2)
    
    for (x <- l3){
      println(x)
    }
    
  }
}