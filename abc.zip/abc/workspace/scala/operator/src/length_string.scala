

object length_string {
  def main (args : Array[String]){
    var palindrome="Dot saw I was Tod"
    var len=palindrome.length()
    println("length is:"+len)
    var o= palindrome.concat(" not saw pod");
    println(o)  
    
    var floatv = 12.18634;
    var intv= 2000
    var stringv = "SScala language"
    
    var fs = printf("float %f"+ " int %d"+" string %s",floatv,intv,stringv)
 
    println(fs)
      
  }
}