

object operator1 {
  
   def main(args:Array[String]){
    var a=60;
    var b=13;
    var c=25;
    var d=25;
    var e=true;
    var f=false;
    
    println("a==b= "+(a==b));
    println("a!=b= "+(a!=b));
    println("a>b= "+(a>b));
    println("a<b= "+(a<b));
    println("b>=a= "+(b>=a));
    println("b<=a "+(b<=a));
    println("e&&f= "+(e&&f));
    println("e||f= "+(e||f));
    println("!(e && f)= "+ (!(e&&f)));
    println("a & b= "+(a & b));
    println("a | b= "+(a | b));
    println("a ^ b= "+(a ^ b));
    println("c "+  (~a));
    println("c " + (a<<2) );
    println("c " +(a>>>2));
    c = a+ b;
    println("c=a+b=> "+ c );
    c +=a;
    println("c+=a=> "+ c );
    c -=a;
    println("c-=a=> "+ c );
    c *=a;
    println("c*=a=> "+ c );
    a= 10; c=15; c/=a;
    println("c/=a=> "+ c );
    a= 10; c=15; c%=a;
    println("c%=a=> "+ c );
    c <<= 2;
    println("c<<2=> "+ c );
    c >>= 2;
    println("c>>2=> "+ c );
    c >>= a;
    println("c>>a=> "+ c );
    c &= 2;
    println("c&=2=> "+ c );
    c ^= 2;
    println("c^=2=> "+ c );
    c >>= 2;
    println("c>>2=> "+ c );
  }
}