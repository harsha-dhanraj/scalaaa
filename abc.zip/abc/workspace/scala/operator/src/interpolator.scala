

object interpolator {
  def main (args :Array[String]){
    val name = "kitkat"
    val height=1.9d

    //s interpolator
    println(s"result=\n a \n b")
    
    //raw interpolator
    println(raw"result=\n a \n b")
    
     println("=========================")
     
     //var z = Array[String](3)
     var z=Array("zara","nuha","ayan")
      println(z(2))
      
     println("=========================")
    println(f"$name%s is $height%2.2f meters tall")
    println(s"Hello, $name")
    println(s"1+1=${1+1}")
  }
}