
 import Array._
object multiArray {
 
   def main(args: Array[String]) {
      var myMatrix = ofDim[Int](4,4)
      
      // build a matrix
      for (i <- 0 to 3) {
         for ( j <- 0 to 3) {
            myMatrix(i)(j) = j;
         }
      }
      
      // Print two dimensional array
      for (i <- 0 to 3) {
         for ( j <- 0 to 3) {
            print(" " + myMatrix(i)(j));
         }
         println();
      }
   }
}
