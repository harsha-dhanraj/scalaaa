

object max3number {
  def max( x:Int,y:Int,z:Int)={
    if (x>y) 
      {
          if (x>z) x
          else  y
      }
    
  }
}