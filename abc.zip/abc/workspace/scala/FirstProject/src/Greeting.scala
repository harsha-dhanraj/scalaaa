

object Greeting {
  def main(args:Array[String]) {
    println("Greetings from Scala")
  }
}