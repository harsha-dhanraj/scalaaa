

object recursiveFun {
  
  def fives(cur:Int,max:Int):Unit={
    if(cur<=max){
      println(cur)
      fives(cur+5,max)
    }
  }
  def main(args:Array[String]){
    fives(0,20)
  
  
  

    
  }
}