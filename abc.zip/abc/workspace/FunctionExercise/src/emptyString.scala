

object emptyString {
  def main(args:Array[String]){
    
     println(area("2"));
  }
  
  def area(r:String):Double={
    r.isEmpty match{
      
      case true=> 0
      
      case false=> math.pow(r.toDouble,2)*math.Pi
    }
  }
    
} 