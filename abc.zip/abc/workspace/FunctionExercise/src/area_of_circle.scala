
import Math._

object area_of_circle {
  def main(args:Array[String]){
    
    area(2);
    
  }
  
  def area(r:Double){
    
    //val area_of_circle=3.14*r*r;
    val area_of_circle=math.Pi*math.pow(r,2);
      println("Area of circle is: "+area_of_circle);
    
  }
}