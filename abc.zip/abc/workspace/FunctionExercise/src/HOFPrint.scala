
//HOF-higher order function

object HOFPrint {
  def printval(v:Any,codeBlock:Any=>Unit){
    codeBlock(v)
    
  }
  
  def main(args:Array[String]){
    printval("Hello",(v:Any)=>println(v))
    printval("C",(v:Any)=>println(v))
    printval(100.35,(v:Any)=>println(v))
  }
}